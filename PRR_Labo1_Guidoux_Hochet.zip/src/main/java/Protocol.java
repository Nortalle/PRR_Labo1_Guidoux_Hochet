public class Protocol {

    static final Integer MULTICAST_PORT     = 4445;
    static final String MULTICAST_ADDRESS   = "228.5.6.7";
    static final String SYNC                = "SYNC";
    static final String FOLLOW_UP           = "FOLLOW_UP";
    static final String DELAY_REQUEST       = "DELAY_REQUEST";
    static final String DELAY_RESPONSE      = "DELAY_RESPONSE";
}
